===================
Deprecated services
===================

This directory contains services that are deprecated and that will be
removed in a future release.
